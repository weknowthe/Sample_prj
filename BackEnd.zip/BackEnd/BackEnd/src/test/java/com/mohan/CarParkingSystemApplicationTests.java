package com.mohan;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
class CarParkingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
