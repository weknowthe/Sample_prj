import React, { Component } from 'react';
import axios from 'axios';
import {Link, Redirect} from 'react-router-dom';

export default class Register extends Component {

    state = {
        firstName: '',
        lastName: '',
        email: '',
        mobNo:'',
        licenseNo:'',
        adharNo:'',
        userName:'',
        password:'',
        redirect: false,
        authError: false,
        isLoading: false,
    };

    handleEmailChange = event => {
        this.setState({ email: event.target.value });
    };
    handlePwdChange = event => {
        this.setState({ password: event.target.value });
    };
    handleFirstNameChange = event => {
        this.setState({ firstName: event.target.value });
    };

    handleLastNameChange = event => {
        this.setState({ lastName: event.target.value });
    };

    handleMobileChange = event => {
        this.setState({mobNo: event.target.value})
    }

    handleLicenceChange = event => {
        this.setState({licenseNo: event.target.value})
    }
    handleUserNameChange = event => {
        this.setState({userName: event.target.value})
    }

    handleAdharChange = event => {
        this.setState({adharNo: event.target.value})
    }

    handleSubmit = event => {
        event.preventDefault();
        this.setState({isLoading: true});
        const url = 'http://localhost:8090/register';

        let regObj = {
            "firstName": this.state.firstName,
            "lastName": this.state.lastName,
            "email": this.state.email,
            "mobNo": this.state.mobNo,
            "licenseNo": this.state.licenseNo,
            "adharNo": this.state.adharNo,
            "userName":this.state.userName,
            "password":this.state.password, 
        }
        axios.post(url, regObj)
            .then(result => {
                this.setState({isLoading: false});
                if (result.data.status !== 'fail') {
                    this.setState({redirect: true, authError: true});
                }else {
                    this.setState({redirect: false, authError: true});
                }
            })
            .catch(error => {
                console.log(error);
                this.setState({ authError: true, isLoading: false });
            });
    };

    renderRedirect = () => {
        if (this.state.redirect) {
            return <Redirect to="/login1" />
        }
    };

    render() {
        const isLoading = this.state.isLoading;
        return (
            <div className="container">
                <div className="card card-login mx-auto mt-5">
                    <div className="card-header">Welcome To User Registeration</div>
                    <div className="card-body">
                        <form onSubmit={this.handleSubmit}>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="inputfirstName">First Name</label>
                                    <input type="text" id="inputfirstName" className="form-control" placeholder="First Name"  name="firstName" onChange={this.handleFirstNameChange} required/>
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="inputLastName">Last Name</label>
                                    <input type="text" id="inputLastName" className="form-control" placeholder="Last Name"  name="lastName" onChange={this.handleLastNameChange} required/>
                                </div>
                            </div>

                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="inputEmail">Email Address</label>
                                    <input id="inputEmail" className={"form-control " + (this.state.authError ? 'is-invalid' : '')} placeholder="Email Address" type="email" name="email" onChange={this.handleEmailChange} autoFocus required/>
                                    <div className="invalid-feedback">
                                        Please provide a valid Email. 
                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="mobNo">Mobile Number</label>
                                    <input type="text" id="mobNo" className="form-control" placeholder="Mobile Number"  name="mobNo" onChange={this.handleMobileChange} required/>
                                   
                                  </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                     <label htmlFor="licenseNo">Vehicle Number</label>
                                    <input type="text" id="licenseNo" className="form-control" placeholder="Vehicle Reg. No."  name="licenseNo" onChange={this.handleLicenceChange} required/>
                                    
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                   <label htmlFor="adharNo">Adhar Number</label>
                                    <input type="text" id="adharNo" className="form-control" placeholder="Adhar Card No."  name="adharNo" onChange={this.handleAdharChange} required/>
                                   
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="userName">User Name</label>
                                    <input type="text" id="userName" className="form-control" placeholder="User Name"  name="userName" onChange={this.handleUserNameChange} required/>
                                    
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <label htmlFor="inputPassword">Password</label>
                                    <input type="password" className="form-control" id="inputPassword" placeholder="******"  name="password" onChange={this.handlePwdChange} required/>
                                   
                                </div>
                            </div>

                            <div className="form-group">
                                <button className="btn btn-primary btn-block" type="submit" disabled={this.state.isLoading ? true : false}>Register &nbsp;&nbsp;&nbsp;
                                    {isLoading ? (
                                        <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    ) : (
                                        <span></span>
                                    )}
                                </button>
                            </div>
                        </form>
                        <div className="text-center">
                            <Link className="d-block small mt-3" to={"/login1"}>Login Your Account</Link>
                            <Link className="d-block small" to={'#'}>Forgot Password?</Link>
                        </div>
                    </div>
                </div>
                {this.renderRedirect()}
            </div>
        );
    }
}


