import React, { Component } from "react";
import "./Homepage.css";
import web from "./home.png";
import cad1 from "./vision.png";
import cad2 from "./vendor.svg";
import cad3 from "./vehicle.svg";

import { NavLink } from "react-router-dom";

export default class Home extends Component {
  render() {
    return (
      <div className="">
        <section className="main_headingmy-5  ">
          <div className=" mx-auto">
            <section id="header" className="d-flex align-items-center">
              <div className="container-fluid nav_bg">
                <div className="row">
                  <div className="col-10 mx-auto  ">
                    <div className="row ">
                      <div className="col-md-6    d-flex justify-content-center flex-column">
                        <h1>
                          Welcome To Home Page
                          <strong className="brand-name"> Park Easy</strong>
                        </h1>
                        <h2 className="my-3">
                          Find Parking Place For Your Vehicle On The GO!!!
                        </h2>
                        <div>
                          <button className="btn-get-started1 ">
                            <NavLink to={"/login1"} className="nav-link">
                              Login
                            </NavLink>
                          </button>
                          &nbsp; &nbsp; &nbsp;
                          <button className="btn-get-started2 ">
                            <NavLink to={"/register"} className="nav-link">
                              Sign Up
                            </NavLink>
                          </button>
                        </div>
                      </div>

                      <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex justify-content-center flex-column header-img">
                        <img
                          src={web}
                          className="img-fluid animated"
                          alt="home img"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </section>

        <section className="main_heading my-3 ">
          <div className="text-center">
            <h1>Our Vision</h1>
          </div>
          <div className="col-10 mx-auto  ">
            <div className="row ">
              <div className="card-deck">
                <div className="card">
                  <img
                    className={"card-img-top"}
                    src={cad1}
                    alt="Card image cap"
                  />
                  <div className="card-body">
                    <h5 className="card-title">
                      Easy To Find Ideal Parking Place
                    </h5>
                    <p className="card-text">
                      We are provinding a Online platform for Finding Ideal
                      parking place for your vehicle. Reducing your unwanted
                      efforts and brings a ease in your work.
                    </p>
                  </div>
                </div>
                <div className="card">
                  <img
                    className="card-img-top"
                    src={cad3}
                    alt="Card image cap"
                  />
                  <div className="card-body">
                    <h5 className="card-title">Parking For Every Type</h5>
                    <p className="card-text">
                      You can search parking irrespective of type of your
                      vehicle. From Two-Wheeler Scooter to Large Vehicle you can
                      search and Park every type of vehicle.
                    </p>
                  </div>
                </div>
                <div className="card">
                  <img
                    className="card-img-top"
                    src={cad2}
                    alt="Card image cap"
                  />
                  <div className="card-body">
                    <h5 className="card-title">
                      Future Scope With Broad Vision
                    </h5>
                    <p className="card-text">
                      In future we are promising to impliment the Vendor Role in
                      our system. To reach this Platform in every corner of
                      Metropolitian Cities of Our Counrty, and Support to
                      #AatmNirbharBharat.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
