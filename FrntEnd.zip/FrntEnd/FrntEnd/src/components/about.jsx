import React from 'react'
import { Link, NavLink } from 'react-router-dom';


const Aboutpage = (props) => {
    return (
        <>
            <section className="my-5">
                <div className="myCard">
                    <div className="row">
                        <div className="col-md-6">
                            
                        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                          
                </div>
            </div>
        </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Aboutpage;