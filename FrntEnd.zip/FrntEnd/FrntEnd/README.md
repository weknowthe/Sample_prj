## Available Scripts

In the project directory, you can run:

#### `git clone https://github.com/gowthamand/react-login-register-crud`
#### `npm install`
#### `npm start`
#### `npm build`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

#### `API URL's`
##### `https://login-register-crud.herokuapp.com`

## `Please Support Us to develop more app's`
### `Please Donate` <a href="https://paypal.me/gowthamdurai?locale.x=en_GB">Donate a 1$</a>
